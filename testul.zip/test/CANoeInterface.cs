﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using CANoe;
using System.Timers;
using System.Diagnostics;

namespace test
{

    class CANoeInterface
    {
        private CANoe.Application myApp;
        private CANoe.Measurement myMeasurement;
        private CANoe.Signal mySignal;
        private CANoe.Bus myBus;
        private CANoe.EnvironmentVariable myEnvVar;
        private string path;
        

        public CANoeInterface()
        {
            Console.WriteLine("Opening CANoe...\n");
            myApp = new CANoe.Application();
            myMeasurement = (CANoe.Measurement)myApp.Measurement;
            System.Threading.Thread.Sleep(10000);
            
        }

        public void startStop(string sTime)
        {
            int Timer = Int32.Parse(sTime);
            Console.WriteLine("Opening " + path + "\n");
            System.Threading.Thread.Sleep(3000);
            myApp.Open(@path, true, true);
            System.Threading.Thread.Sleep(3000);
            myMeasurement.Start();
            System.Threading.Thread.Sleep(3000);
            readThings();
            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Start();
            Console.WriteLine("Testing for " + Timer + " hours now...");
            while (true)
            {
                TimeSpan time = stopWatch.Elapsed;
                if (time.TotalHours == Timer)
                {
                    Console.WriteLine("Test lasted 3hours, closing CANoe");
                    close();
                    break;
                }
            }


        }

        public void setPath(string a)
        {
            path = a;

        }
        public void readThings()
        {
            CANoe.Environment myEnviroment = (CANoe.Environment)myApp.Environment;
            myBus = (CANoe.Bus)myApp.get_Bus("CAN");

            myEnvVar = (CANoe.EnvironmentVariable)myEnviroment.GetVariable("Env_VehSpd_X");
            myEnvVar.Value = 100;

            System.Threading.Thread.Sleep(1000);
            Console.WriteLine("Test started");
        }
        public void close()
        {
            myMeasurement.Stop();
            System.Threading.Thread.Sleep(120000);
            myApp.Quit();
        }

    }
}
