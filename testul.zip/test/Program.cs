﻿using System;
using CANoe;
using System.Runtime.InteropServices;
using System.IO;
using System.Threading;
namespace test
{
    class Program
    {
        
        static void Main(string[] args)
        {
           
            CANoeInterface myInt = new CANoeInterface();
            myInt.setPath(args[0]);
            myInt.startStop(args[1]);
            
            
                
        }
    }
}
